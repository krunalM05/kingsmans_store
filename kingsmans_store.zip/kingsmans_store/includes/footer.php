<?php
include 'includes/loginmodal.php';
?>
<footer>
    <div class="container">
        <div class="row">
            <div class="col-xs-4">
                <h3>Information</h3>
                <p><a href='aboutus.php'>About Us</a></p>
                <p><a href='contactus.php'>Contact Us</a></p>
            </div>
            <div class="col-xs-4">
                <h3>My Account</h3>
                <p><a href="#" data-toggle="modal" data-target="#loginmodal"> Log in</a></p>
                <p><a href='signup.php'>Signup</a></p>
            </div>
            <div class="col-xs-4">
                <h3>Contact Us</h3>
                <p>Copyright &copy; Kingsman's Store. All Rights Reserved |</p>
                <p>Contact:+91-123-000000</p>
                
            </div>
        </div>
    </div>
</footer>